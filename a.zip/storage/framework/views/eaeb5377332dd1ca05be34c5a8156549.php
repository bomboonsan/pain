<label for="<?php echo e($key ?? ''); ?>" class="flex justify-between p-3 w-full bg-white border border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500">
    <span class="text-lg"><?php echo e($value ?? ''); ?></span>
    <input
    id="<?php echo e($key ?? ''); ?>"
    name="symptoms[<?php echo e($key ?? ''); ?>]"
    <?php echo e($checked === '1' ? 'checked' : ''); ?>

    type="checkbox"
    class="shrink-0 ms-auto mt-0.5 border-gray-200 rounded text-blue-600 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none"
    >
</label>
<?php /**PATH /home/bomboonsan/Desktop/laravel/paine-guide/resources/views/components/app/symptoms-select.blade.php ENDPATH**/ ?>