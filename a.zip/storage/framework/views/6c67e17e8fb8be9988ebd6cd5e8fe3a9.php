<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="p-2 overflow-hidden">
        <?php if (isset($component)) { $__componentOriginal6a2d163e475ea3ef3e9088acd82eeadd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a2d163e475ea3ef3e9088acd82eeadd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.step','data' => ['step' => '2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.step'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['step' => '2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a2d163e475ea3ef3e9088acd82eeadd)): ?>
<?php $attributes = $__attributesOriginal6a2d163e475ea3ef3e9088acd82eeadd; ?>
<?php unset($__attributesOriginal6a2d163e475ea3ef3e9088acd82eeadd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a2d163e475ea3ef3e9088acd82eeadd)): ?>
<?php $component = $__componentOriginal6a2d163e475ea3ef3e9088acd82eeadd; ?>
<?php unset($__componentOriginal6a2d163e475ea3ef3e9088acd82eeadd); ?>
<?php endif; ?>
        <div class="mt-5 mb-8">
            <h1 class="page-title">เลือกระดับความปวด</h1>
        </div>
        <div class="my-20"></div>
        <div class="relative">
            <?php if (isset($component)) { $__componentOriginal27d3fc481fcfd0b6bb5f6f732a683ad8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27d3fc481fcfd0b6bb5f6f732a683ad8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.level-symptoms','data' => ['symptomsLevel' => ''.e($symptomsLevel).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.level-symptoms'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['symptomsLevel' => ''.e($symptomsLevel).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27d3fc481fcfd0b6bb5f6f732a683ad8)): ?>
<?php $attributes = $__attributesOriginal27d3fc481fcfd0b6bb5f6f732a683ad8; ?>
<?php unset($__attributesOriginal27d3fc481fcfd0b6bb5f6f732a683ad8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27d3fc481fcfd0b6bb5f6f732a683ad8)): ?>
<?php $component = $__componentOriginal27d3fc481fcfd0b6bb5f6f732a683ad8; ?>
<?php unset($__componentOriginal27d3fc481fcfd0b6bb5f6f732a683ad8); ?>
<?php endif; ?>
        </div>
        <div class="flex justify-center gap-5">
            <?php if (isset($component)) { $__componentOriginal947db9623e909f28f31a841a13b7929f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal947db9623e909f28f31a841a13b7929f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.btn-secondary','data' => ['text' => 'ย้อนกลับ','url' => ''.e(route('pain')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.btn-secondary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => 'ย้อนกลับ','url' => ''.e(route('pain')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal947db9623e909f28f31a841a13b7929f)): ?>
<?php $attributes = $__attributesOriginal947db9623e909f28f31a841a13b7929f; ?>
<?php unset($__attributesOriginal947db9623e909f28f31a841a13b7929f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal947db9623e909f28f31a841a13b7929f)): ?>
<?php $component = $__componentOriginal947db9623e909f28f31a841a13b7929f; ?>
<?php unset($__componentOriginal947db9623e909f28f31a841a13b7929f); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalda0d3f380fbee028e68ec16c01e9a352 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda0d3f380fbee028e68ec16c01e9a352 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.btn-primary','data' => ['text' => 'ถัดไป']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.btn-primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => 'ถัดไป']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda0d3f380fbee028e68ec16c01e9a352)): ?>
<?php $attributes = $__attributesOriginalda0d3f380fbee028e68ec16c01e9a352; ?>
<?php unset($__attributesOriginalda0d3f380fbee028e68ec16c01e9a352); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda0d3f380fbee028e68ec16c01e9a352)): ?>
<?php $component = $__componentOriginalda0d3f380fbee028e68ec16c01e9a352; ?>
<?php unset($__componentOriginalda0d3f380fbee028e68ec16c01e9a352); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>


<?php if(session('error')): ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    Swal.fire({
        title: "<?php echo e(session('error')); ?>",
        icon: "warning",
        showConfirmButton: false,
    });
</script>
<?php endif; ?>

<script>
    const btnPrimary = document.querySelector('#btn-primary');
    const submit = document.querySelector('#submit');

    btnPrimary.addEventListener('click', () => {
        submit.click();
    })
</script>
<?php /**PATH /home/bomboonsan/Desktop/laravel/paine-guide/resources/views/app/symptoms.blade.php ENDPATH**/ ?>