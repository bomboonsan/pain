<button id="btn-primary" class="btn bg-primary text-white hover:bg-[#779d98] inline-flex justify-center items-center p-1 min-w-[150px] rounded-lg" type="submit">
    {{ $text ?? '' }}
</button>
