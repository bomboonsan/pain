import './bootstrap';
import './preline';

// import '../../node_modules/preline/dist/preline';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
