<a href="<?php echo e($url ?? '#'); ?>" class="btn bg-[#f6f6f6] text-primary hover:bg-primary hover:text-white inline-flex justify-center items-center p-1 min-w-[150px] rounded-lg" type="submit">
    <?php echo e($text ?? ''); ?>

</a>
<?php /**PATH /home/bomboonsan/Desktop/laravel/paine-guide/resources/views/components/app/btn-secondary.blade.php ENDPATH**/ ?>