<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="p-2 overflow-hidden">
        <?php if (isset($component)) { $__componentOriginal6a2d163e475ea3ef3e9088acd82eeadd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a2d163e475ea3ef3e9088acd82eeadd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.step','data' => ['step' => '5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.step'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['step' => '5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a2d163e475ea3ef3e9088acd82eeadd)): ?>
<?php $attributes = $__attributesOriginal6a2d163e475ea3ef3e9088acd82eeadd; ?>
<?php unset($__attributesOriginal6a2d163e475ea3ef3e9088acd82eeadd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a2d163e475ea3ef3e9088acd82eeadd)): ?>
<?php $component = $__componentOriginal6a2d163e475ea3ef3e9088acd82eeadd; ?>
<?php unset($__componentOriginal6a2d163e475ea3ef3e9088acd82eeadd); ?>
<?php endif; ?>
        <div class="mt-5 mb-8">
            
        </div>
        <div class="relative p-2 md:px-10 md:py-5">
            <div class="rounded-lg border border-neutral-400/20 p-2 md:py-10 md:px-5">
                <div class="mb-5 w-1/3 md:w-1/4 mx-auto">
                    <img src="<?php echo e(asset('images/hand_pain.png')); ?>" alt="" class="w-full h-auto">
                </div>
                <p class="text-center text-xl md:text-2xl font-bold mb-5">
                    สรุป
                </p>
                <div class="space-y-2 font-medium text-sm md:text-lg">
                    <p>
                        <span class="text-primary inline-block md:min-w-[130px] mr-3">ตำแหน่งอาการ:</span>
                        <?php $__currentLoopData = $position_text_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->last): ?>
                            <?php echo e($text); ?>

                            <?php else: ?>
                            <?php echo e($text); ?> ,
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                    <p>
                        <span class="text-primary inline-block md:min-w-[130px] mr-3">ระดับความปวด:</span>
                        <?php echo e($symptomsLevel); ?>

                    </p>
                    <p>
                        <span class="text-primary inline-block md:min-w-[130px] mr-3">ลักษณะการปวด:</span>
                        <?php $__currentLoopData = $symptoms_text; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->last): ?>
                            <?php echo e($text); ?>

                            <?php else: ?>
                            <?php echo e($text); ?> ,
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                    <p>
                        <span class="text-primary inline-block md:min-w-[130px] mr-3">ยาที่รับประทาน::</span>
                        <?php $__currentLoopData = $medReceived; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->last): ?>
                            <?php echo e($item['name']); ?>

                            <?php else: ?>
                            <?php echo e($item['name']); ?> ,
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div>

            </div>
        </div>
        <div class="flex justify-center gap-5">
            <form action="<?php echo e(route('caseSubmit')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button id="submit" type="submit" class="button-primary" >บันทึก</button>
            </form>
            <button id="btnDialog" class="hidden" aria-haspopup="dialog" aria-expanded="false" aria-controls="hs-slide-up-animation-modal" data-hs-overlay="#hs-slide-up-animation-modal">SHOW</button>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>

<?php if(session('success')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(() => { document.getElementById('btnDialog').click(); }, 200)
            setTimeout(() => {
                window.location.href = "<?php echo e(route('home')); ?>";
            }, 3000)
        })
    </script>
<?php endif; ?>

<div id="hs-slide-up-animation-modal" class="hs-overlay hidden size-full fixed top-0 start-0 z-[80] overflow-x-hidden overflow-y-auto pointer-events-none flex items-center" role="dialog" tabindex="-1" aria-labelledby="hs-slide-up-animation-modal-label">
    <div class="hs-overlay-open:mt-7 hs-overlay-open:opacity-100 hs-overlay-open:duration-500 mt-14 opacity-0 ease-out transition-all sm:max-w-md sm:w-full m-3 sm:mx-auto">
        <div class="flex flex-col bg-white border shadow-sm rounded-xl pointer-events-auto">

            <div class="p-4 md:px-10 md:py-10 overflow-y-auto text-center">
                <img src="<?php echo e(asset('images/icon-success.png')); ?>" alt="" class="w-24 h-auto mx-auto mb-5">
                <p class="mt-1 text-lg font-semibold">
                    บันทึกเรียบร้อย!
                </p>
                <p class="mb-5">
                    ขอบคุณสำหรับการบันทึก
                </p>
                <a href="<?php echo e(route('home')); ?>" type="button" class="button-primary shadow-md" data-hs-overlay="#hs-slide-up-animation-modal">เสร็จสิ้น</a>
            </div>

        </div>
    </div>
</div>
<?php /**PATH /home/bomboonsan/Desktop/laravel/paine-guide/resources/views/app/result.blade.php ENDPATH**/ ?>