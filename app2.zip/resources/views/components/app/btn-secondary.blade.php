<a href="{{ $url ?? '#' }}" class="btn bg-[#f6f6f6] text-primary hover:bg-primary hover:text-white inline-flex justify-center items-center p-1 min-w-[150px] rounded-lg" type="submit">
    {{ $text ?? '' }}
</a>
